package com.example.payroll

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent { PayrollApp(db.dao(), this) }
    }
}

private fun money(v: Double) = String.format(Locale.US, "%.2f", v)
private fun monthName(m: Int) = listOf("", "يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر")[m]

@Composable
fun PayrollApp(dao: PayrollDao, context: Context) {
    val scope = rememberCoroutineScope()
    val employees by dao.employees().collectAsState(initial = emptyList())
    var month by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.MONTH) + 1) }
    var year by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
    var tab by remember { mutableIntStateOf(0) }
    var day by remember { mutableIntStateOf(1) }

    val start = "%04d-%02d-01".format(year, month)
    val daysInMonth = Calendar.getInstance().apply {
        set(year, month - 1, 1)
        set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
    }.get(Calendar.DAY_OF_MONTH)
    val end = "%04d-%02d-%02d".format(year, month, daysInMonth)
    val selectedDate = "%04d-%02d-%02d".format(year, month, day)

    val period by dao.period(month, year).collectAsState(initial = null)
    val rows by dao.payrollRows(month, year, start, end).collectAsState(initial = emptyList())
    val attendance by dao.attendanceForDate(selectedDate).collectAsState(initial = emptyList())

    LaunchedEffect(month, year) {
        dao.ensurePeriod(PayrollPeriod(month = month, year = year))
        day = 1
    }

    val workingDays = daysInMonth // التقويم الميلادي: 28/29/30/31
    Scaffold(
        topBar = {
            Column {
                Text(
                    "رواتب الموظفين",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(16.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = {
                        if (month == 1) { month = 12; year-- } else month--
                    }) { Text("‹") }
                    Text("${monthName(month)} $year  •  $workingDays يوم") 
                    TextButton(onClick = {
                        if (month == 12) { month = 1; year++ } else month++
                    }) { Text("›") }
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, label = { Text("الرواتب") }, icon = {})
                NavigationBarItem(tab == 1, { tab = 1 }, label = { Text("الحضور") }, icon = {})
                NavigationBarItem(tab == 2, { tab = 2 }, label = { Text("الموظفون") }, icon = {})
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> PayrollScreen(rows, workingDays, period, month, year, dao, context, scope)
                1 -> AttendanceScreen(employees, attendance, day, daysInMonth, selectedDate, dao, scope)
                2 -> EmployeesScreen(employees, dao, scope)
            }
        }
    }
}

@Composable
private fun PayrollScreen(
    rows: List<PayrollRow>,
    daysInMonth: Int,
    period: PayrollPeriod?,
    month: Int,
    year: Int,
    dao: PayrollDao,
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope
) {
    var showSettings by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf<PayrollRow?>(null) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("طريقة الحساب", style = MaterialTheme.typography.titleMedium)
                Text("الراتب الشهري ثابت، وأجر اليوم = الراتب الأساسي ÷ عدد أيام الشهر الميلادي.")
                Text("الغياب يخصم أجر اليوم تلقائياً، ونصف اليوم يخصم نصف أجر اليوم.")
                Text("الأيام غير المسجلة لا تعتبر غياباً ولا يخصم منها شيء.")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { showSettings = true }) { Text("إعدادات الشهر") }
                    OutlinedButton(onClick = {
                        PdfExporter.export(context, rows, daysInMonth, month, year)
                    }) { Text("PDF") }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows, key = { it.employeeId }) { r ->
                val daily = r.basicSalary / daysInMonth
                val absenceDeduction = (r.absentDays + r.halfDays * 0.5) * daily
                val earnedBasic = r.basicSalary - absenceDeduction
                val net = earnedBasic + r.allowances + r.bonuses - r.advances - r.deductions
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(r.name, style = MaterialTheme.typography.titleMedium)
                        Text("رقم: ${r.employeeNumber}  •  ${r.job}")
                        Text("حاضر: ${r.presentDays}  | غائب: ${r.absentDays} | نصف يوم: ${r.halfDays}")
                        Text("أجر اليوم: ${money(daily)}")
                        Text("خصم الغياب: ${money(absenceDeduction)}")
                        Text("الصافي: ${money(net)}", style = MaterialTheme.typography.titleLarge)
                        TextButton(onClick = { showDetails = r }) { Text("تفاصيل الراتب") }
                    }
                }
            }
        }
    }

    if (showSettings) {
        var unused = period?.workingDays ?: daysInMonth
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("إعدادات الشهر") },
            text = {
                Column {
                    Text("عدد أيام الشهر يحسب تلقائياً من التقويم الميلادي: $daysInMonth يوم.")
                    Text("لا يمكن تغييره؛ لأنه أساس أجر اليوم في هذا النظام.")
                    Text("أجر اليوم = الراتب الأساسي ÷ $daysInMonth")
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("إغلاق") } }
        )
    }

    showDetails?.let { r ->
        val daily = r.basicSalary / daysInMonth
        val absenceDeduction = (r.absentDays + r.halfDays * 0.5) * daily
        val earnedBasic = r.basicSalary - absenceDeduction
        val net = earnedBasic + r.allowances + r.bonuses - r.advances - r.deductions
        AlertDialog(
            onDismissRequest = { showDetails = null },
            title = { Text("تفاصيل ${r.name}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("الراتب الأساسي: ${money(r.basicSalary)}")
                    Text("عدد أيام الشهر: $daysInMonth")
                    Text("أجر اليوم: ${money(daily)}")
                    Text("الحضور: ${r.presentDays} يوم")
                    Text("الغياب: ${r.absentDays} يوم")
                    Text("نصف اليوم: ${r.halfDays} يوم")
                    Text("الإجازة المدفوعة: ${r.paidLeaveDays} يوم")
                    Text("قيمة خصم الغياب ونصف اليوم: ${money(absenceDeduction)}")
                    Text("الأساسي المستحق: ${money(earnedBasic)}")
                    Text("البدلات: ${money(r.allowances)}")
                    Text("المكافآت: ${money(r.bonuses)}")
                    Text("السلف: ${money(r.advances)}")
                    Text("خصومات أخرى: ${money(r.deductions)}")
                    Text("صافي الراتب: ${money(net)}", style = MaterialTheme.typography.titleLarge)
                }
            },
            confirmButton = { TextButton(onClick = { showDetails = null }) { Text("إغلاق") } }
        )
    }
}

@Composable
private fun AttendanceScreen(
    employees: List<Employee>,
    attendance: List<Attendance>,
    day: Int,
    daysInMonth: Int,
    date: String,
    dao: PayrollDao,
    scope: kotlinx.coroutines.CoroutineScope
) {
    val map = attendance.associateBy { it.employeeId }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("اليوم $day / $daysInMonth")
                Text(date)
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                employees.forEach {
                    scope.launch {
                        dao.saveAttendance(Attendance(employeeId = it.id, date = date, status = "PRESENT"))
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تسجيل حضور الجميع") }

        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(employees, key = { it.id }) { e ->
                val current = map[e.id]?.status
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text(e.name, style = MaterialTheme.typography.titleMedium)
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            StatusButton("حاضر", current == "PRESENT") {
                                scope.launch { dao.saveAttendance(Attendance(employeeId=e.id, date=date, status="PRESENT")) }
                            }
                            StatusButton("غائب", current == "ABSENT") {
                                scope.launch { dao.saveAttendance(Attendance(employeeId=e.id, date=date, status="ABSENT")) }
                            }
                            StatusButton("نصف يوم", current == "HALF_DAY") {
                                scope.launch { dao.saveAttendance(Attendance(employeeId=e.id, date=date, status="HALF_DAY")) }
                            }
                            StatusButton("إجازة مدفوعة", current == "PAID_LEAVE") {
                                scope.launch { dao.saveAttendance(Attendance(employeeId=e.id, date=date, status="PAID_LEAVE")) }
                            }
                        }
                        Text("الحالة: ${when(current) {
                            "PRESENT" -> "حاضر — أجر اليوم مستحق"
                            "ABSENT" -> "غائب — سيخصم أجر اليوم"
                            "HALF_DAY" -> "نصف يوم — سيخصم نصف أجر اليوم"
                            "PAID_LEAVE" -> "إجازة مدفوعة"
                            else -> "غير مسجل"
                        }}")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick) { Text(label) }
    else OutlinedButton(onClick = onClick) { Text(label) }
}

@Composable
private fun EmployeesScreen(
    employees: List<Employee>,
    dao: PayrollDao,
    scope: kotlinx.coroutines.CoroutineScope
) {
    var showAdd by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Button(onClick = { showAdd = true }, Modifier.fillMaxWidth()) { Text("إضافة موظف") }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(employees, key = { it.id }) { e ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(e.name, style = MaterialTheme.typography.titleMedium)
                        Text("رقم الموظف: ${e.employeeNumber}")
                        Text("الوظيفة: ${e.job}")
                        Text("الراتب الأساسي: ${money(e.basicSalary)}")
                    }
                }
            }
        }
    }
    if (showAdd) {
        AddEmployeeDialog(
            onDismiss = { showAdd = false },
            onSave = { name, number, job, salary ->
                scope.launch {
                    dao.insertEmployee(Employee(
                        name = name, employeeNumber = number, job = job,
                        basicSalary = salary
                    ))
                    showAdd = false
                }
            }
        )
    }
}

@Composable
private fun AddEmployeeDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var job by remember { mutableStateOf("") }
    var salary by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة موظف") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(name, { name = it }, label={Text("اسم الموظف")})
                OutlinedTextField(number, { number = it }, label={Text("رقم الموظف")})
                OutlinedTextField(job, { job = it }, label={Text("الوظيفة")})
                OutlinedTextField(
                    salary, { salary = it },
                    label={Text("الراتب الأساسي")},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val s = salary.toDoubleOrNull() ?: 0.0
                if (name.isNotBlank() && number.isNotBlank() && s > 0) onSave(name, number, job, s)
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

object PdfExporter {
    fun export(context: Context, rows: List<PayrollRow>, daysInMonth: Int, month: Int, year: Int) {
        val pdf = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 13f }
        var pageNo = 1
        var y = 45f

        fun newPage(): PdfDocument.Page {
            val info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo++).create()
            y = 45f
            return pdf.startPage(info)
        }

        var page = newPage()
        fun line(text: String, size: Float = 13f) {
            paint.textSize = size
            paint.textAlign = Paint.Align.RIGHT
            page.canvas.drawText(text, 560f, y, paint)
            y += 23f
        }

        line("كشف رواتب $month/$year", 18f)
        line("عدد أيام الشهر: $daysInMonth — أجر اليوم = الراتب الأساسي ÷ $daysInMonth", 12f)
        y += 10f

        rows.forEach { r ->
            if (y > 780f) {
                pdf.finishPage(page)
                page = newPage()
            }
            val daily = r.basicSalary / daysInMonth
            val absenceDeduction = (r.absentDays + r.halfDays * 0.5) * daily
            val earnedBasic = r.basicSalary - absenceDeduction
            val net = earnedBasic + r.allowances + r.bonuses - r.advances - r.deductions
            line("${r.name} (${r.employeeNumber})", 14f)
            line("الأساسي: ${money(r.basicSalary)} | أجر اليوم: ${money(daily)}")
            line("حضور: ${r.presentDays} | غياب: ${r.absentDays} | نصف يوم: ${r.halfDays}")
            line("خصم الغياب: ${money(absenceDeduction)} | صافي الراتب: ${money(net)}")
            y += 8f
        }

        pdf.finishPage(page)
        val dir = File(context.getExternalFilesDir(null), "payroll")
        dir.mkdirs()
        val file = File(dir, "payroll_${year}_${month}.pdf")
        file.outputStream().use { pdf.writeTo(it) }
        pdf.close()
    }
}
