package com.example.payroll

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "employees",
    indices = [Index(value = ["employeeNumber"], unique = true)]
)
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val employeeNumber: String,
    val job: String = "",
    val department: String = "",
    val basicSalary: Double,
    val defaultAllowances: Double = 0.0,
    val active: Boolean = true
)

@Entity(
    tableName = "payroll",
    indices = [Index(value = ["employeeId", "month", "year"], unique = true)]
)
data class Payroll(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val month: Int,
    val year: Int,
    val allowances: Double = 0.0,
    val bonuses: Double = 0.0,
    val advances: Double = 0.0,
    val deductions: Double = 0.0
)

@Entity(
    tableName = "attendance",
    indices = [Index(value = ["employeeId", "date"], unique = true)]
)
data class Attendance(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val date: String,
    val status: String
)

@Entity(
    tableName = "payroll_period",
    indices = [Index(value = ["month", "year"], unique = true)]
)
data class PayrollPeriod(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val month: Int,
    val year: Int
)

data class PayrollRow(
    val employeeId: Long,
    val name: String,
    val employeeNumber: String,
    val job: String,
    val basicSalary: Double,
    val allowances: Double,
    val bonuses: Double,
    val advances: Double,
    val deductions: Double,
    val presentDays: Int,
    val absentDays: Int,
    val halfDays: Int,
    val paidLeaveDays: Int
)

@Dao
interface PayrollDao {
    @Query("SELECT * FROM employees WHERE active = 1 ORDER BY name")
    fun employees(): Flow<List<Employee>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployee(employee: Employee)

    @Query("SELECT * FROM payroll_period WHERE month=:month AND year=:year LIMIT 1")
    fun period(month: Int, year: Int): Flow<PayrollPeriod?>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun ensurePeriod(period: PayrollPeriod)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePeriod(period: PayrollPeriod)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAttendance(attendance: Attendance)

    @Query("SELECT * FROM attendance WHERE date=:date")
    fun attendanceForDate(date: String): Flow<List<Attendance>>

    @Query("""
        SELECT e.id AS employeeId, e.name AS name, e.employeeNumber AS employeeNumber,
               e.job AS job, e.basicSalary AS basicSalary,
               COALESCE(p.allowances, e.defaultAllowances) AS allowances,
               COALESCE(p.bonuses, 0) AS bonuses,
               COALESCE(p.advances, 0) AS advances,
               COALESCE(p.deductions, 0) AS deductions,
               COALESCE(SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END),0) AS presentDays,
               COALESCE(SUM(CASE WHEN a.status='ABSENT' THEN 1 ELSE 0 END),0) AS absentDays,
               COALESCE(SUM(CASE WHEN a.status='HALF_DAY' THEN 1 ELSE 0 END),0) AS halfDays,
               COALESCE(SUM(CASE WHEN a.status='PAID_LEAVE' THEN 1 ELSE 0 END),0) AS paidLeaveDays
        FROM employees e
        LEFT JOIN payroll p
          ON p.employeeId=e.id AND p.month=:month AND p.year=:year
        LEFT JOIN attendance a
          ON a.employeeId=e.id AND a.date BETWEEN :startDate AND :endDate
        WHERE e.active=1
        GROUP BY e.id, p.id
        ORDER BY e.name
    """)
    fun payrollRows(
        month: Int, year: Int, startDate: String, endDate: String
    ): Flow<List<PayrollRow>>
}

@Database(
    entities = [Employee::class, Payroll::class, Attendance::class, PayrollPeriod::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): PayrollDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "employee_payroll.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
